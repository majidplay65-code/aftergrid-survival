# راهنمای راه‌اندازی — فاز 0 (Setup) و فاز 1+2 (Core Systems + Player)

این پوشه دقیقاً باید داخل پوشه‌ی `res://` پروژه‌ی Godot 4.7.2 تو کپی بشه
(یعنی محتوای این پوشه رو بریز کنار فایل project.godot).

## قدم ۱ — ساخت پروژه
1. Godot 4.7.2 (Standard build) رو باز کن.
2. New Project بزن، Renderer رو روی **Forward+** یا **Mobile** بذار (برای شروع Mobile سبک‌تره).
3. فایل‌های این پوشه رو داخل res:// کپی کن، دقیقاً با همین نام پوشه‌ها.

## قدم ۲ — ثبت Autoload ها (بسیار مهم و به‌ترتیب)
مسیر: **Project → Project Settings → Autoload**

به همین ترتیب اضافه کن (ترتیب مهم است چون EventBus باید قبل از بقیه لود بشه):

| Path | Node Name |
|---|---|
| `res://autoloads/event_bus.gd` | `EventBus` |
| `res://autoloads/game_state.gd` | `GameState` |
| `res://autoloads/scene_manager.gd` | `SceneManager` |
| `res://autoloads/save_manager.gd` | `SaveManager` |

بعد از اضافه‌کردن هر کدام، دکمه‌ی **Add** رو بزن. اسم نود (ستون دوم) باید دقیقاً همینایی باشه که نوشتم چون در کدها با همین نام‌ها صداشون می‌زنیم (مثلاً `EventBus.player_died.emit()`).

## قدم ۳ — تعریف Input Map
مسیر: **Project → Project Settings → Input Map**

این اکشن‌ها رو بساز و برای هرکدام حداقل یک کلید اختصاص بده:

| Action Name | کلید پیشنهادی |
|---|---|
| `move_forward` | W |
| `move_back` | S |
| `move_left` | A |
| `move_right` | D |
| `run` | Shift |
| `jump` | Space |
| `interact` | E |

(اکشن‌های `ui_cancel` از قبل توسط Godot ساخته شده‌اند — Esc.)

## قدم ۴ — ساخت Scene بازیکن (Player.tscn)
داخل `res://entities/player/` یک صحنه‌ی جدید بساز با این ساختار دقیق نودها:

```
Player  (CharacterBody3D)  <- اسکریپت: entities/player/player.gd
├── CollisionShape3D        <- یک CapsuleShape3D بهش بده
├── MeshInstance3D           <- یک CapsuleMesh موقت برای دیدن بازیکن
├── CameraPivot  (Node3D)
│   └── Camera3D
└── StateMachine  (Node)     <- اسکریپت: core/state_machine/state_machine.gd
    ├── IdleState  (Node)    <- اسکریپت: entities/player/states/idle_state.gd
    ├── WalkState  (Node)    <- اسکریپت: entities/player/states/walk_state.gd
    └── RunState   (Node)    <- اسکریپت: entities/player/states/run_state.gd
```

نکات حیاتی:
- نام هر نود (IdleState, WalkState, RunState) باید **دقیقاً** همین باشه، چون `transition_to(&"WalkState")` با نام نود کار می‌کنه.
- روی نود `StateMachine`، در Inspector، فیلد `Initial State` رو به `IdleState` وصل کن (drag & drop از Scene Tree).
- روی هر یک از سه نود State (Idle/Walk/Run)، در Inspector فیلد `Player` رو به نود ریشه‌ی `Player` وصل کن (drag & drop).
- `CameraPivot` رو یک‌کم بالاتر از مرکز کپسول قرار بده (مثلاً Y = 1.6) تا شبیه ارتفاع چشم بشه.

## قدم ۵ — تست
1. یک صحنه‌ی تست بساز (`res://levels/test_level.tscn`) با یک `StaticBody3D` صاف به‌عنوان زمین (Plane یا Box بزرگ با CollisionShape3D).
2. نمونه‌ای از `Player.tscn` رو داخلش Instance کن.
3. این صحنه رو به‌عنوان Main Scene تنظیم کن: **Project Settings → Application → Run → Main Scene**.
4. Run بزن (F5). باید بتونی با WASD حرکت کنی، با Shift بدوی، و با Space بپری.

## چک‌لیست صحت (Definition of Done فاز 0+1+2)
- [ ] بازیکن با WASD حرکت می‌کند و شتاب/اصطکاک طبیعی دارد
- [ ] با نگه‌داشتن Shift سرعت افزایش می‌یابد و استامینا (در کد، از طریق `player.stats.stamina`) کم می‌شود
- [ ] با رهاکردن Shift یا اتمام استامینا، به‌صورت خودکار به WalkState برمی‌گردد
- [ ] Space باعث پرش می‌شود
- [ ] موس دوربین را می‌چرخاند و Esc موس را آزاد/قفل می‌کند
- [ ] در خروجی Output هیچ Error یا Warning قرمزی دیده نمی‌شود

اگر همه‌ی این‌ها تیک خورد، فاز 0+1+2 رسماً کامل است و می‌روی سراغ فاز 3 (World & Interaction).

## نکته درباره‌ی استفاده از AI برای فازهای بعدی
برای هر فاز بعدی، این متن رو دقیقاً به‌عنوان context اول به مدل بده:
"من از Godot 4.7 با GDScript typed استفاده می‌کنم. معماری من: Resource برای داده، Node-based State Machine برای رفتار، EventBus Autoload برای ارتباط بین سیستم‌ها. این فایل‌های موجودم هستند: [فایل‌های این پوشه رو پیست کن]. حالا فاز بعدی (Interaction System) رو با همین سبک و بدون تغییر معماری فعلی پیاده‌سازی کن."
